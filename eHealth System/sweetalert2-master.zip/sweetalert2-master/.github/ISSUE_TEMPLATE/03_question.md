---
name: Question
about: Ask a question
labels:

---

Please post your question to StackOverflow: https://stackoverflow.com/questions/ask
Make sure to add the `sweetalert2` tag to the question.

Thank you.

---

Has SweetAlert2 helped you create an amazing application? You can show your support by making a donation:

- GitHub Sponsors: https://github.com/sponsors/limonte
- PayPal: https://www.paypal.me/limonte
- Bitcoin: `16Z7RvFv7PsV3XzFvchYwPnRfw9KeLTZQJ`
- Ether: `0x192096161eB2273f12b1cB4E31aBB09Bfc03a7F3`
- Bitcoin Cash: `qz28x66hrljtdz3052p8ya3cmkwwva5avy0msz2ej3`
- Stellar: `GDUM4VJZYDNRHBTKUQBOPC374AP6MMMVOJDMSHIPEJPEMBCY4ZHH6NDY`
